import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  final databasereference = Firestore.instance;
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // Widget _buildBody(BuildContext context, ){
  //   return StreamBuilder<QuerySnapshot>(
  //     stream: Firestore.instance.collection('Voters').snapshots(),
  //     builder: (context, snapshot){
  //       if(!snapshot.hasData)
  //         return LinearProgressIndicator();
  //       return _buildList(context, snapshot.data.documents);

  //     },
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            "Online Voting",
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              StreamBuilder(
                stream: Firestore.instance.collection('Voters').snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return LinearProgressIndicator();
                  return ListView.builder(
                    shrinkWrap: true,
                    primary: false,
                    //itemExtent: 80.0,
                    itemCount: snapshot.data.documents.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onDoubleTap: (){
                          votereset(snapshot.data.documents[index]);
                        },
                        child: Card(
                        child: GestureDetector(
                          onTap: () {
                            votecount(snapshot.data.documents[index]);
                          },
                          child: Padding(
                            padding: EdgeInsets.all(8),
                            child: ListTile(
                              title: Text(snapshot.data.documents[index]['name']),
                              trailing: Text(
                                snapshot.data.documents[index]['votes']
                                    .toString(),
                              ),
                            ),
                          ),
                        ),
                      ),
                      );
                    },
                  );
                },
              ),
              Container(
                child: Column(
                  children: <Widget>[

                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  votereset(DocumentSnapshot doc){
    Firestore.instance.runTransaction((transaction) async{
      DocumentSnapshot freshSnap = await transaction.get(doc.reference);
      await transaction.update(freshSnap.reference, {
        'votes': 0,
      });
    });

  }

  votecount(DocumentSnapshot doc) {
    Firestore.instance.runTransaction((transaction) async {
      DocumentSnapshot freshSnap = await transaction.get(doc.reference);
      await transaction.update(freshSnap.reference,{
        'votes' : freshSnap['votes'] + 1,
      });
    });
    // doc.reference.updateData({
    //   'votes' : doc['votes'] + 1,
    // });
  }
}
